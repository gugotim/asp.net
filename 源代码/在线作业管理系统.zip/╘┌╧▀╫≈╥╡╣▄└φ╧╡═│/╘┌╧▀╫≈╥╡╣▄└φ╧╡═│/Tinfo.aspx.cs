﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;
using System.Web.Security;

namespace 在线作业管理系统
{
    public partial class Tinfo : System.Web.UI.Page
    {
        string dbstr;
        OleDbConnection conn=new OleDbConnection();
        OleDbCommand cmd;
        string selectCmd;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (DateTime.Now.Hour > 12)
            {
                AorPLab.Text = "下午好!";
            }
            else AorPLab.Text = "早上好!";

            dbstr="Provider=Microsoft.Jet.OLEDB.4.0;data source="+MapPath("data/am.mdb");
            conn.ConnectionString = dbstr;
            conn.Open();

            //已布置作业数
            selectCmd="select count(*) from work_info";
            cmd=new OleDbCommand(selectCmd,conn);
            publishedLab.Text = cmd.ExecuteScalar().ToString();
            if (Convert.ToInt32(cmd.ExecuteScalar()) != 0)
            {
                publishedLab.Text = "查看已布置的" + cmd.ExecuteScalar().ToString() + "项作业";
            }
            else publishedLab.Text = "你还没有布置任何作业";

            //待批改作业数
            selectCmd="SELECT count(*) FROM [work_info] WHERE ([截止日期] >= '"+DateTime.Now.ToString("yyyy-MM-dd")
                + "' AND [未提交] > 0) OR ([待批改] > 0)";
            cmd = new OleDbCommand(selectCmd, conn);
            if (Convert.ToInt32(cmd.ExecuteScalar()) != 0)
            {
                TomarkLab.Text = "批改" + cmd.ExecuteScalar().ToString() + "项作业";
            }
            else TomarkLab.Text = "现在没有需要批改的作业";

            //可公布成绩作业数
            selectCmd = "SELECT count(*) FROM [work_info] WHERE (([待批改] = 0) AND ([截止日期] < '"+DateTime.Now.ToString("yyyy-MM-dd")
                + "' OR [未提交] = 0 ) AND ([公布否] = '否'))";
            cmd = new OleDbCommand(selectCmd, conn);
            ToAnnounceLab.Text = cmd.ExecuteScalar().ToString();
            if (Convert.ToInt32(cmd.ExecuteScalar()) != 0)
            {
                ToAnnounceLab.Text = "有" + cmd.ExecuteScalar().ToString() + "项作业可以公布成绩咯";
            }
            else ToAnnounceLab.Text = "还没有可以公布成绩的作业";

            //可查看成绩作业数
            selectCmd = "select count(*) from [work_info] where [公布否] = '是'";
            cmd = new OleDbCommand(selectCmd, conn);
            AnnouncedLab.Text = cmd.ExecuteScalar().ToString();
            if (Convert.ToInt32(cmd.ExecuteScalar()) != 0)
            {
                AnnouncedLab.Text = cmd.ExecuteScalar().ToString() + "项作业已经揭红榜了，来看看排名吧";
            }
            else AnnouncedLab.Text = "没有已经公布成绩的作业";

            selectCmd = "select [姓名] from [Teacher] where [工号] ='" + HttpContext.Current.User.Identity.Name + "'";
            cmd = new OleDbCommand(selectCmd, conn);
            if (cmd.ExecuteScalar()!=null)
            {
                TeachnameLab.Text = cmd.ExecuteScalar().ToString();
            }
            else TeachnameLab.Text = HttpContext.Current.User.Identity.Name;

            conn.Close();
        }
    }
}