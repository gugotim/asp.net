﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;

namespace 在线作业管理系统
{
    public partial class announce : System.Web.UI.Page
    {
        string dbstr;
        OleDbConnection conn = new OleDbConnection();
        OleDbCommand cmd;
        OleDbDataReader reader;
        string q_no;
        protected void Page_Load(object sender, EventArgs e)
        {
            dbstr = "Provider=Microsoft.Jet.OLEDB.4.0;data source=" + MapPath("../data/am.mdb");
            conn.ConnectionString = dbstr;
            Label1.Text = DateTime.Now.ToString("yyyy-MM-dd");

            if (!IsPostBack)
            {
                conn.Open();
                string selectCmd = "select count(*) from [work_info] where ([截止日期]< '" 
                    + DateTime.Now.ToString("yyyy-MM-dd") + "' OR [未提交] = 0) and [待批改]=0 and [公布否]='否'";
                cmd = new OleDbCommand(selectCmd, conn);
                if (Convert.ToInt32(cmd.ExecuteScalar()) == 0)
                {
                    alert2.InnerHtml = "目前没有可供公布成绩的作业~";
                }
                else alert2.InnerHtml = "请选择以查看提交情况并酌情公布成绩";
                conn.Close();
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            q_no = GridView1.SelectedRow.Cells[1].Text;
            conn.Open();
            string updateCmd = "update [work_info] set [公布否]='是' where [题号]='" + q_no + "'";
            cmd = new OleDbCommand(updateCmd, conn);
            cmd.ExecuteNonQuery();

            updateCmd = "update [answer] set [评分]='未按时提交作业' where [题号]='" + q_no + "' and [提交否]='否'";
            cmd = new OleDbCommand(updateCmd, conn);
            cmd.ExecuteNonQuery();
            conn.Close();
            Response.Write("<script>alert('公布成功');location.href='../check/result1.aspx';</script>");
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            q_no = GridView1.SelectedRow.Cells[1].Text;
            string selectCmd = "select [学号] from [answer] where [题号]='" + q_no + "' and [提交否]='否'";
            conn.Open();
            cmd = new OleDbCommand(selectCmd, conn);
            if (Convert.ToInt32(cmd.ExecuteScalar())==0)
            {
                alert2.InnerText = "所有同学都按时提交了作业";
            }
            else
            {
                alert2.InnerText = "没交作业的有:     ";
                reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    alert2.InnerText += reader[0].ToString() + "    ";
                }
            }
            conn.Close();
            Button1.Enabled = true;
        }
    }
}