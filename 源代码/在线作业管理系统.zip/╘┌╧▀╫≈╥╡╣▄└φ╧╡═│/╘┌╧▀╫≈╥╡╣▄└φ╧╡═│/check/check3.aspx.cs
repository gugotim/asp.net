﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;

namespace 在线作业管理系统
{
    public partial class check31 : System.Web.UI.Page
    {
        string dbstr;
        OleDbConnection conn = new OleDbConnection();
        OleDbCommand cmd;
        OleDbDataReader reader;
        string q_no,stu_no;
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                q_no = Request.Cookies["no"].Value;
                stu_no = Request.Cookies["sid"].Value;
            }
            catch (System.Exception ex)
            {
                Response.Redirect("result1.aspx");
            }

            dbstr = "Provider=Microsoft.Jet.OLEDB.4.0;data source=" + MapPath("../data/am.mdb");
            conn.ConnectionString = dbstr;
            if (!IsPostBack)
            {
                conn.Open();
                string selectCmd = "select * from [answer] where [题号]='" + q_no + "' and [学号]='" + stu_no + "'";
                cmd = new OleDbCommand(selectCmd, conn);
                if (cmd.ExecuteScalar() != null)
                {
                    reader = cmd.ExecuteReader();
                    //获取学号和答案
                    while (reader.Read())
                    {
                        SnoTxb.Text = reader["学号"].ToString();
                        Ans1.Text = reader["答案1"].ToString();
                        Ans2.Text = reader["答案2"].ToString();
                        Ans3.Text = reader["答案3"].ToString();
                        ScoreTxb.Text = reader["评分"].ToString();
                    }
                    if (ScoreTxb.Text.Equals("false"))
                    {
                        ScoreTxb.Text = "0";
                    }
                    //获取题目信息
                    selectCmd = "select [类型],[题目] from [assignment] where [题号]='" + q_no + "'";
                    cmd = new OleDbCommand(selectCmd, conn);
                    reader = cmd.ExecuteReader();
                    Label[] type = { Qtype1, Qtype2, Qtype3 };
                    TextBox[] question = { Qtxb1, Qtxb2, Qtxb3 };
                    int i = 0;
                    while (reader.Read())
                    {
                        type[i].Text = reader[0].ToString() + ":";
                        question[i].Text = reader[1].ToString();
                        i++;
                    }

                }
                conn.Close();
            }
        }

        protected void Button1_Click1(object sender, EventArgs e)
        {
            Response.Redirect("result2.aspx");
        }
    }
}