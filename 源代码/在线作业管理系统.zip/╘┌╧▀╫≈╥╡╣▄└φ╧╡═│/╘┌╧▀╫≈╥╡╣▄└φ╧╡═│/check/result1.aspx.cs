﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;

namespace 在线作业管理系统
{
    public partial class result1 : System.Web.UI.Page
    {
        string dbstr;
        OleDbConnection conn = new OleDbConnection();
        OleDbCommand cmd;
        OleDbDataReader reader;
        string q_no;
        protected void Page_Load(object sender, EventArgs e)
        {
            dbstr = "Provider=Microsoft.Jet.OLEDB.4.0;data source=" + MapPath("../data/am.mdb");
            conn.ConnectionString = dbstr;
            if (!IsPostBack)
            {
                string selectCmd = "select count(*) from [work_info] where [公布否]='是'";
                cmd = new OleDbCommand(selectCmd, conn);
                conn.Open();
                if (Convert.ToInt32(cmd.ExecuteScalar()) == 0)
                {
                    alert2.InnerText = "目前没有公布成绩的作业";
                }
                else alert2.InnerText = "请选择以查看排名情况";
                conn.Close();
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            q_no = GridView1.SelectedRow.Cells[1].Text;
            Response.Cookies["no"].Value = q_no;
            Response.Redirect("result2.aspx");
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Button1.Enabled = true;
        }
    }
}