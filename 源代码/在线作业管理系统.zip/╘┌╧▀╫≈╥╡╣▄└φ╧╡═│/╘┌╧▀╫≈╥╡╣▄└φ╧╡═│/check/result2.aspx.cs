﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;

namespace 在线作业管理系统
{
    public partial class result2 : System.Web.UI.Page
    {
        string dbstr;
        string q_no,stu_no;
        int qnum;
        OleDbConnection conn=new OleDbConnection();
        OleDbCommand cmd;
        OleDbDataReader reader;
        protected void Page_Load(object sender, EventArgs e)
        {
            dbstr = "Provider=Microsoft.Jet.OLEDB.4.0;data source=" + MapPath("../data/am.mdb");
            conn.ConnectionString = dbstr;
            try
            {
                q_no = Request.Cookies["no"].Value;
                alert2.InnerText = "题号:" + q_no+"   (tips:点击学号和评分可以改变排名顺序)";
            }
            catch (System.Exception ex)
            {
                Response.Redirect("result1.aspx");            	
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            stu_no = GridView1.SelectedRow.Cells[1].Text;
            string selectCmd = "select [题数] from [work_info] where [题号]='" + q_no + "'";
            conn.Open();
            cmd = new OleDbCommand(selectCmd, conn);
            qnum = Convert.ToInt32(cmd.ExecuteScalar());
            conn.Close();
            Response.Cookies["no"].Value = q_no;
            Response.Cookies["sid"].Value = stu_no;
            switch (qnum)
            {
                case 1: Response.Redirect("check1.aspx"); break;
                case 2: Response.Redirect("check2.aspx"); break;
                case 3: Response.Redirect("check3.aspx"); break;
            }
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Button1.Enabled = true;
        }
    }
}