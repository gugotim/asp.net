﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using System.Data;
using System.Data.OleDb;

namespace 在线作业管理系统
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        string dbstr;
        OleDbConnection conn = new OleDbConnection();
        OleDbCommand cmd;
        OleDbDataReader reader;
        protected void Page_Load(object sender, EventArgs e)
        {
            UnameTxb.Focus();
            dbstr = "Provider=Microsoft.Jet.OLEDB.4.0;data source=" + MapPath("data/am.mdb");
            conn.ConnectionString = dbstr;
            if (!IsPostBack)
            {
                if (HttpContext.Current.User.Identity.IsAuthenticated)
                {
                    UnameTxb.Text = HttpContext.Current.User.Identity.Name;
                    if (HttpContext.Current.User.IsInRole("Student"))
                    {
                        herolist.SelectedIndex = 0;
                    }
                    if (HttpContext.Current.User.IsInRole("Student"))
                    {
                        herolist.SelectedIndex = 1;
                    }
                    if (HttpContext.Current.User.IsInRole("admin"))
                    {
                        herolist.SelectedIndex = 2;
                    }
                    PwdTxb.Focus();
                }
                else UnameTxb.Focus();
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string selectCmd="", role="";
            switch (herolist.SelectedIndex)
            {
                case 0: role = "Student"; selectCmd = "select count(*) from [stu] where [学号]='" + UnameTxb.Text + "'";break;
                case 1: role = "Teacher"; selectCmd = "select count(*) from [Teacher] where [工号]='" + UnameTxb.Text + "'"; break;
                case 2: role = "admin"; selectCmd = "select count(*) from [admin] where [用户名] ='"+UnameTxb.Text+"'"; break;
            }
            cmd = new OleDbCommand(selectCmd, conn);
            conn.Open();
            if (Convert.ToInt32(cmd.ExecuteScalar()) != 0)
            {
                switch (role)
                {
                    case "Student": selectCmd = "select * from [stu] where [学号]='" + UnameTxb.Text + "'"; break;
                    case "Teacher": selectCmd = "select * from [Teacher] where [工号]='" + UnameTxb.Text + "'"; break;
                    case "admin": selectCmd = "select * from [admin] where [用户名] ='" + UnameTxb.Text + "'"; break;
                }
                cmd = new OleDbCommand(selectCmd, conn);
                reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    if (PwdTxb.Text.Equals(reader["密码"]))
                    {
                        //创建带有角色信息的票券
                        FormsAuthenticationTicket ticket = new FormsAuthenticationTicket(1, UnameTxb.Text,
                            DateTime.Now, DateTime.Now.AddMinutes(30), CheckBox1.Checked, role);
                        //创建加密COOKIE
                        string hash = FormsAuthentication.Encrypt(ticket);
                        HttpCookie cook = new HttpCookie(FormsAuthentication.FormsCookieName, hash);
                        if (ticket.IsPersistent)
                        {
                            cook.Expires = ticket.Expiration;
                        }
                        //向客户端加入cookie
                        Response.Cookies.Add(cook);
                        switch (role)
                        {
                            case "Student": Response.Redirect("stu/Sinfo.aspx"); break;
                            case "Teacher": Response.Redirect("Tinfo.aspx"); break;
                            case "admin": Response.Redirect("manager/stuinfo.aspx"); break;
                        }
                    }
                    else Msg.Text = "密码错误";
                }
            }
            else
            {
                switch (herolist.SelectedIndex)
                {
                    case 0: Msg.Text = "无此学生"; break;
                    case 1: Msg.Text = "无此教师"; break;
                    case 2: Msg.Text = "无此管理员"; break;
                }
            }
            conn.Close();
        }
    }
}