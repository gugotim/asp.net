﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;

namespace 在线作业管理系统.manager
{
    public partial class assignment : System.Web.UI.Page
    {
        string dbstr, qno;
        OleDbConnection conn = new OleDbConnection();
        OleDbCommand cmd;
        protected void Page_Load(object sender, EventArgs e)
        {
            dbstr = "Provider=Microsoft.Jet.OLEDB.4.0;data source=" + MapPath("../data/am.mdb");
            conn.ConnectionString = dbstr;
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string deleteCmd;
            qno = GridView1.SelectedRow.Cells[1].Text;
            conn.Open();

            deleteCmd = "delete from [work_info] where [题号]='" + qno + "'";
            cmd = new OleDbCommand(deleteCmd, conn);
            cmd.ExecuteNonQuery();
            deleteCmd = "delete from [assignment] where [题号]='" + qno + "'";
            cmd = new OleDbCommand(deleteCmd, conn);
            cmd.ExecuteNonQuery();
            deleteCmd = "delete from [answer] where [题号]='" + qno + "'";
            cmd = new OleDbCommand(deleteCmd, conn);
            cmd.ExecuteNonQuery();

            conn.Close();
            Response.Redirect("assignment.aspx");
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Button1.Enabled = true;
        }
    }
}