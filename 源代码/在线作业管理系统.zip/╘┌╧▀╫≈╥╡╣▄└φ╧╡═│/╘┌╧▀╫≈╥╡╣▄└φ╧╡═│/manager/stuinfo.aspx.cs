﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;

namespace 在线作业管理系统.manager
{
    public partial class stuinfo : System.Web.UI.Page
    {
        string dbstr, selectCmd;
        OleDbConnection conn = new OleDbConnection();
        OleDbCommand cmd;
        protected void Page_Load(object sender, EventArgs e)
        {
            dbstr = "Provider=Microsoft.Jet.OLEDB.4.0;data source=" + MapPath("../data/am.mdb");
            conn.ConnectionString = dbstr;
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (CustomValidator1.IsValid)
            {
                conn.Open();
                string insertCmd = "insert into [stu]([学号],[密码],[姓名]) values(?,?,?)";
                cmd = new OleDbCommand(insertCmd, conn);
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("学号", StuNoTxb.Text);
                cmd.Parameters.AddWithValue("密码", StuNoTxb.Text);
                cmd.Parameters.AddWithValue("姓名", NameTxb.Text);
                try
                {
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    Response.Redirect("stuinfo.aspx");
                }
                catch (System.Exception ex)
                {
                    conn.Close();
                    Response.Write("<script>alert('插入失败，好像哪里出了错误..');location.href='stuinfo.aspx';</script>");
                }
            }
            else StuNoTxb.Focus();
        }

        protected void StuNoTxb_TextChanged(object sender, EventArgs e)
        {
            PwdTxb.Text = StuNoTxb.Text;
            NameTxb.Focus();
        }

        protected void CustomValidator1_ServerValidate(object source, ServerValidateEventArgs args)
        {
            conn.Open();
            selectCmd = "select count(*) from [stu] where [学号]='" + args.Value + "'";
            cmd = new OleDbCommand(selectCmd, conn);
            if (Convert.ToInt32(cmd.ExecuteScalar()) == 0)
            {
                args.IsValid = true;
            }
            else args.IsValid = false;
            conn.Close();
        }
    }
}