﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;

namespace 在线作业管理系统
{
    public partial class check : System.Web.UI.Page
    {
        string dbstr;
        OleDbConnection conn = new OleDbConnection();
        OleDbCommand cmd;
        protected void Page_Load(object sender, EventArgs e)
        {
            time.Text = DateTime.Now.ToString("yyyy-MM-dd");
            dbstr = "Provider=Microsoft.Jet.OLEDB.4.0;data source=" + MapPath("../data/am.mdb");
            conn.ConnectionString = dbstr;

            string selectCmd = "select count(*) from [work_info] where ([待批改] > 0) OR (([截止日期] >= '" + time.Text + "') AND ([未提交] > 0))";
            cmd = new OleDbCommand(selectCmd, conn);
            conn.Open();
            if (Convert.ToInt32(cmd.ExecuteScalar()) == 0)
            {
                alert2.InnerText = "目前没有需要批改的作业~";
            }
            else alert2.InnerText = "请选择以批改作业";
            conn.Close();
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Button1.Enabled = true;
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string q_no=GridView1.SelectedRow.Cells[1].Text;
            string jgm = GridView1.SelectedRow.Cells[3].Text;
            string q_number = GridView1.SelectedRow.Cells[5].Text;

            if (jgm.Equals("100分")) jgm = "1";
            else jgm = "2";
            Response.Cookies["id"].Value = q_no;
            Response.Cookies["jgm"].Value = jgm;
            switch (q_number)
            {
                case "1": Response.Redirect("mark1.aspx"); break;
                case "2": Response.Redirect("mark2.aspx"); break;
                case "3": Response.Redirect("mark3.aspx"); break;
            }
        }
    }
}