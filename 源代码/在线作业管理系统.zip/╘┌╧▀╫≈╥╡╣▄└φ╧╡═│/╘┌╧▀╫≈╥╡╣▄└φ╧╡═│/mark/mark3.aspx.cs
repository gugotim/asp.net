﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;

namespace 在线作业管理系统
{
    public partial class check3 : System.Web.UI.Page
    {
        string dbstr;
        OleDbConnection conn=new OleDbConnection();
        OleDbCommand cmd;
        OleDbDataReader reader;
        string q_no;
        string judgement;
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                judgement = Request.Cookies["jgm"].Value;
                q_no = Request.Cookies["id"].Value;
            }
            catch (System.Exception ex)
            {
                Response.Redirect("default.aspx");
            }

            dbstr = "Provider=Microsoft.Jet.OLEDB.4.0;data source=" + MapPath("../data/am.mdb");
            conn.ConnectionString = dbstr;
            if (!IsPostBack)
            {
                if (judgement.Equals("1"))
                {
                    ScoreTxb.Visible = true;
                    RegularExpressionValidator4.Enabled = true;
                }
                else
                {
                    ScoreDdl.Items.Clear();
                    ScoreDdl.Items.Add("优");
                    ScoreDdl.Items.Add("良");
                    ScoreDdl.Items.Add("及格");
                    ScoreDdl.Items.Add("差");
                    ScoreDdl.Enabled = true;
                }

                conn.Open();
                string selectCmd = "select top 1 * from [answer] where [题号]='" + q_no + "' and [评分]='false' and [提交否]='是'";
                cmd = new OleDbCommand(selectCmd, conn);
                if (cmd.ExecuteScalar() != null)
                {
                    reader = cmd.ExecuteReader();
                    //获取学号和答案
                    while (reader.Read())
                    {   
                        SnoTxb.Text = reader["学号"].ToString();
                        Ans1.Text = reader["答案1"].ToString();
                        Ans2.Text = reader["答案2"].ToString();
                        Ans3.Text = reader["答案3"].ToString();
                    }
                    //获取题目信息
                    selectCmd = "select [类型],[题目] from [assignment] where [题号]='" + q_no + "'";
                    cmd = new OleDbCommand(selectCmd, conn);
                    reader = cmd.ExecuteReader();
                    Label[] type = { Qtype1, Qtype2, Qtype3 };
                    TextBox[] question = { Qtxb1, Qtxb2, Qtxb3 };
                    int i = 0;
                    while (reader.Read())
                    {
                        type[i].Text = reader[0].ToString() + ":";
                        question[i].Text = reader[1].ToString();
                        i++;
                    }

                }
                else
                {
                    selectCmd = "select [未提交] from [work_info] where [题号]='" + q_no + "'";
                    cmd = new OleDbCommand(selectCmd, conn);
                    string undone_no = cmd.ExecuteScalar().ToString();
                    Response.Write("<script>alert('此作业目前已批改完,还待"+undone_no+"个学生提交');location.href='default.aspx';</script>");
                }
                conn.Close();
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string updateCmd;
            if (judgement.Equals("1"))
            {
                updateCmd = "update [answer] set [评分]='" + ScoreTxb.Text + "' where [题号]='" + q_no + "' and [学号]='" 
                    + SnoTxb.Text+"'";
            }
            else
            {
                updateCmd = "update [answer] set [评分]='" + ScoreDdl.SelectedValue + "' where [题号]='" + q_no + "' and [学号]='" 
                    + SnoTxb.Text + "'";
            }
            conn.Open();
            cmd = new OleDbCommand(updateCmd, conn);
            cmd.ExecuteNonQuery();

            updateCmd = "update [work_info] set [待批改]=[待批改]-1 where [题号]='" + q_no + "'";
            cmd = new OleDbCommand(updateCmd, conn);
            cmd.ExecuteNonQuery();

            conn.Close();
            Response.Redirect("mark3.aspx");
        }
    }
}