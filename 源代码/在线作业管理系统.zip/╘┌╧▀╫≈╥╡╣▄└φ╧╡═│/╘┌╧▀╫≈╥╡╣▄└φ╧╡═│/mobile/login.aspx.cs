﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;
using System.Web.Security;

namespace 在线作业管理系统.mobile
{
    public partial class kkk : System.Web.UI.Page
    {
        string dbstr,selectCmd,role;
        OleDbConnection conn = new OleDbConnection();
        OleDbCommand cmd;
        protected void Page_Load(object sender, EventArgs e)
        {
            dbstr = "provider=Microsoft.Jet.OLEDB.4.0;data source=" + MapPath("../data/am.mdb");
            conn.ConnectionString = dbstr;
            if (RadioButton1.Checked)
            {
                role = "Student";
            }
            if (RadioButton2.Checked)
            {
                role = "Teacher";
            }
            if (RadioButton3.Checked)
            {
                role = "admin";
            }
            if (!IsPostBack)
            {
                UnameTxb.Focus();
            }
        }

        protected void LoginBtn_Click(object sender, EventArgs e)
        {
            if (CustomValidator1.IsValid)
            {
                //创建带有角色信息的票券
                FormsAuthenticationTicket ticket = new FormsAuthenticationTicket(1, UnameTxb.Text,
                    DateTime.Now, DateTime.Now.AddMinutes(30), false, role);
                //创建加密COOKIE
                string hash = FormsAuthentication.Encrypt(ticket);
                HttpCookie cook = new HttpCookie(FormsAuthentication.FormsCookieName, hash);
                if (ticket.IsPersistent)
                {
                    cook.Expires = ticket.Expiration;
                }
                //向客户端加入cookie
                Response.Cookies.Add(cook);
                switch (role)
                {
                    case "Student": Response.Redirect("stu/index.aspx"); break;
                    case "Teacher": Response.Redirect("../Tinfo.aspx"); break;
                    case "admin": Response.Redirect("../manager/stuinfo.aspx"); break;
                }
            }
        }

        protected void CustomValidator1_ServerValidate(object source, ServerValidateEventArgs args)
        {
            switch (role)
            {
                case "Student": selectCmd = "select [密码] from [stu] where [学号]='" + UnameTxb.Text + "'"; break;
                case "Teacher": selectCmd = "select [密码] from [Teacher] where [工号]='" + UnameTxb.Text + "'"; break;
                case "admin": selectCmd = "select [密码] from [admin] where [用户名]='" + UnameTxb.Text + "'"; break;
            }
            cmd = new OleDbCommand(selectCmd, conn);
            conn.Open();
            if (cmd.ExecuteScalar() != null)
            {
                if (cmd.ExecuteScalar().ToString().Equals(PwdTxb.Text))
                {
                    args.IsValid = true;
                }
                else
                {
                    args.IsValid = false;
                    CustomValidator1.Text = "密码错误";
                    PwdTxb.Focus();
                }
            }
            else
            {
                args.IsValid = false;
                CustomValidator1.Text = "用户不存在";
                UnameTxb.Focus();
            }
            conn.Close();
        }
    }
}