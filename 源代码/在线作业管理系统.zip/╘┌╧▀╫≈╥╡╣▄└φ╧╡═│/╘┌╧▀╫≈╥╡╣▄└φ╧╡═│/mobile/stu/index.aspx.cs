﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;
using System.Web.Security;

namespace 在线作业管理系统.mobile.stu
{
    public partial class index : System.Web.UI.Page
    {
        string dbstr,selectCmd;
        OleDbConnection conn = new OleDbConnection();
        OleDbCommand cmd;
        protected void Page_Load(object sender, EventArgs e)
        {
            dbstr = "Provider=Microsoft.Jet.OLEDB.4.0;data source=" + MapPath("~/data/am.mdb");
            conn.ConnectionString = dbstr;
            if (!IsPostBack)
            {
                get_undone_num();
                get_submited_num();
                get_expired_num();
                get_marked_num();
            }
        }

        protected void get_undone_num()
        {
            conn.Open();
            //待提交作业数
            selectCmd = "SELECT count(*) FROM [work_info],[answer] WHERE ([截止日期] >= '"
                + DateTime.Now.ToString("yyyy-MM-dd")
                + "') and ([work_info].[题号] = [answer].[题号]) and ([answer].[提交否] = '否') and([学号] = '" 
                + HttpContext.Current.User.Identity.Name + "')";
            cmd = new OleDbCommand(selectCmd, conn);
            UndoneLab.Text = cmd.ExecuteScalar().ToString();
            conn.Close();
        }

        protected void get_submited_num()
        {
            conn.Open();
            //待批改作业数
            selectCmd = "SELECT count(*) FROM [work_info],[answer] WHERE ([work_info].[题号] = [answer].[题号]) and ([answer].[提交否] = '是')"
                + " and([学号] = '" + HttpContext.Current.User.Identity.Name + "') and([work_info].[公布否] = '否')";
            cmd = new OleDbCommand(selectCmd, conn);
            SubmitedLab.Text = cmd.ExecuteScalar().ToString();
            conn.Close();
        }

        protected void get_expired_num()
        {
            conn.Open();
            //已过期作业数
            selectCmd = "SELECT count(*) FROM [work_info],[answer] WHERE ([截止日期] < '" + DateTime.Now.ToString("yyyy-MM-dd")
                + "') and ([work_info].[题号] = [answer].[题号]) and ([answer].[提交否] = '否') and([学号] = '" 
                + HttpContext.Current.User.Identity.Name + "')";
            cmd = new OleDbCommand(selectCmd, conn);
            ExpiredLab.Text = cmd.ExecuteScalar().ToString();
            conn.Close();
        }

        protected void get_marked_num()
        {
            conn.Open();
            //已评分作业数
            selectCmd = "SELECT count(*) FROM [answer],[work_info] WHERE ([学号] = '" + HttpContext.Current.User.Identity.Name
                + "') and [work_info].[公布否] = '是' and ([work_info].[题号] = [answer].[题号]) and ([answer].[提交否] <> '否')";
            cmd = new OleDbCommand(selectCmd, conn);
            MarkedLab.Text = cmd.ExecuteScalar().ToString();
            conn.Close();
        }

        protected void LoginStatus1_LoggingOut(object sender, LoginCancelEventArgs e)
        {
            FormsAuthentication.SignOut();
            Response.Redirect("../login.aspx");
        }
    }
}