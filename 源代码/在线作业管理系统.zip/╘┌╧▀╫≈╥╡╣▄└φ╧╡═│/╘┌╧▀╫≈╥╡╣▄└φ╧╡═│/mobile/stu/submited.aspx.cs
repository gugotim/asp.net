﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;

namespace 在线作业管理系统.mobile.stu
{
    public partial class submited : System.Web.UI.Page
    {
        string dbstr, selectCmd, qno;
        static int qnumber;
        OleDbConnection conn = new OleDbConnection();
        OleDbCommand cmd;
        OleDbDataReader reader;
        protected void Page_Load(object sender, EventArgs e)
        {
            dbstr = "Provider=Microsoft.Jet.OLEDB.4.0;data source=" + MapPath("../../data/am.mdb");
            conn.ConnectionString = dbstr;
            if (!IsPostBack)
            {
                try
                {
                    StuNoLab.Text = HttpContext.Current.User.Identity.Name;
                }
                catch (System.Exception ex)
                {
                    Response.Write("<script>alert('请以学号登陆');location.href='../login.aspx';</script>");
                }
                get_submited_qno();//获取待批改作业的第一条记录的题号
                if (qno != null)
                {
                    fresh_id(qno);//读取题目信息和答案
                }
                else justfy_interface(0);
            }
        }

        protected void get_submited_qno()
        {
            conn.Open();
            //待批改作业的第一条记录
            selectCmd = "SELECT [work_info].[题号] FROM [work_info],[answer] WHERE ([work_info].[题号] = [answer].[题号]) and ([answer].[提交否] = '是')"
                + " and([学号] = '" + HttpContext.Current.User.Identity.Name + "') and([work_info].[公布否] = '否')";
            cmd = new OleDbCommand(selectCmd, conn);

            if (cmd.ExecuteScalar() != null)
            {
                qno = cmd.ExecuteScalar().ToString();
            }
            else
            {
                qno = null;
            }
            conn.Close();
        }


        protected void fresh_id(string qid)
        {
            conn.Open();
            selectCmd = "select [题目],[类型] from [assignment] where [题号]='"
                + qid + "'";
            cmd = new OleDbCommand(selectCmd, conn);
            reader = cmd.ExecuteReader();
            Label[] question = { Q1Lab, Q2Lab, Q3Lab };
            Label[] type = { QtpLab1, QtpLab2, QtpLab3 };
            int i = 0;
            while (reader.Read())
            {
                question[i].Text = reader["题目"].ToString();

                type[i].Text = (i + 1).ToString() + "." + reader["类型"].ToString() + "：";
                i++;
            }
            qnumber = i;
            justfy_interface(i);
            selectCmd = "select [截止日期] from [work_info] where [题号]='" + qid + "'";
            cmd = new OleDbCommand(selectCmd, conn);
            deadline.Text = cmd.ExecuteScalar().ToString();
            //获取答案
            switch (qnumber)
            {
                case 1: selectCmd = "select [答案1] from [answer] where [学号]='"
                    + HttpContext.Current.User.Identity.Name + "' and [题号]='" + qid + "'"; break;
                case 2: selectCmd = "select [答案1],[答案2] from [answer] where [学号]='"
                    + HttpContext.Current.User.Identity.Name + "' and [题号]='" + qid + "'"; break;
                case 3: selectCmd = "select [答案1],[答案2],[答案3] from [answer] where [学号]='"
                    + HttpContext.Current.User.Identity.Name + "' and [题号]='" + qid + "'"; break;
            }
            cmd = new OleDbCommand(selectCmd, conn);
            reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                switch (qnumber)
                {
                    case 1: Ans1Txb.Text = reader["答案1"].ToString(); break;
                    case 2:
                        {
                            Ans1Txb.Text = reader["答案1"].ToString();
                            Ans2Txb.Text = reader["答案2"].ToString(); break;
                        }
                    case 3:
                        {
                            Ans1Txb.Text = reader["答案1"].ToString();
                            Ans2Txb.Text = reader["答案2"].ToString();
                            Ans3Txb.Text = reader["答案3"].ToString(); break;
                        }
                }
            }
            conn.Close();
        }

        protected void justfy_interface(int qnum)
        {
            switch (qnum)
            {
                case 0:
                    Label2.Text = "暂时没有等待批改的作业";
                    DropDownList1.Visible = false;
                    Label1.Visible = false;
                    QtpLab1.Visible = false; QtpLab2.Visible = false; QtpLab3.Visible = false;
                    Q1Lab.Visible = false; Q2Lab.Visible = false; Q3Lab.Visible = false;
                    Ans1Txb.Visible = false; Ans2Txb.Visible = false; Ans3Txb.Visible = false; break;
                case 1:
                    Label2.Text = "截止日期";
                    Label1.Visible = true; DropDownList1.Visible = true;
                    QtpLab1.Visible = true; QtpLab2.Visible = false; QtpLab3.Visible = false;
                    Q1Lab.Visible = true; Q2Lab.Visible = false; Q3Lab.Visible = false;
                    Ans1Txb.Visible = true; Ans2Txb.Visible = false; Ans3Txb.Visible = false; break;
                case 2:
                    Label2.Text = "截止日期";
                    Label1.Visible = true; DropDownList1.Visible = true;
                    QtpLab1.Visible = true; QtpLab2.Visible = true; QtpLab3.Visible = false;
                    Q1Lab.Visible = true; Q2Lab.Visible = true; Q3Lab.Visible = false;
                    Ans1Txb.Visible = true; Ans2Txb.Visible = true; Ans3Txb.Visible = false; break;
                case 3:
                    Label2.Text = "截止日期";
                    Label1.Visible = true; DropDownList1.Visible = true;
                    QtpLab1.Visible = true; QtpLab2.Visible = true; QtpLab3.Visible = true;
                    Q1Lab.Visible = true; Q2Lab.Visible = true; Q3Lab.Visible = true;
                    Ans1Txb.Visible = true; Ans2Txb.Visible = true; Ans3Txb.Visible = true; break;
            }
        }
        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            fresh_id(DropDownList1.SelectedValue);
        }
    }
}