﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;

namespace 在线作业管理系统.mobile.stu
{
    public partial class undone : System.Web.UI.Page
    {
        string dbstr,selectCmd,qno;
        static int qnumber;
        OleDbConnection conn = new OleDbConnection();
        OleDbCommand cmd;
        OleDbDataReader reader;
        protected void Page_Load(object sender, EventArgs e)
        {
            dbstr = "Provider=Microsoft.Jet.OLEDB.4.0;data source=" + MapPath("../../data/am.mdb");
            conn.ConnectionString = dbstr;
            if (!IsPostBack)
            {
                try
                {
                    StuNoLab.Text = HttpContext.Current.User.Identity.Name;
                    TimeLab.Text = DateTime.Now.ToString("yyyy-MM-dd");
                }
                catch (System.Exception ex)
                {
                    Response.Write("<script>alert('请以学号登陆');location.href='login.aspx';</script>");
                }
                get_undone_qno();
                if (qno != null)
                {
                    fresh_id(qno);
                }
                else justfy_interface(0);
            }
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            fresh_id(DropDownList1.SelectedValue);
        }

        protected void get_undone_qno()
        {
            conn.Open();
            //待提交作业的第一条记录
            selectCmd = "SELECT [work_info].[题号] FROM [work_info],[answer] WHERE ([截止日期] >= '" + DateTime.Now.ToString("yyyy-MM-dd")
                + "') and ([work_info].[题号] = [answer].[题号]) and ([answer].[提交否] = '否') and([学号] = '" 
                + HttpContext.Current.User.Identity.Name + "')";
            cmd = new OleDbCommand(selectCmd, conn);

            if (cmd.ExecuteScalar() != null)
            {
                qno = cmd.ExecuteScalar().ToString(); 
            }
            else
            {
                qno = null; 
            }
            conn.Close();
        }

        protected void fresh_id(string qid)
        {
            conn.Open();
            selectCmd = "select [题目],[类型] from [assignment] where [题号]='"
                + qid + "'";
            cmd = new OleDbCommand(selectCmd, conn);
            reader = cmd.ExecuteReader();
            Label[] question = { Q1Lab, Q2Lab, Q3Lab };
            Label[] type = { QtpLab1, QtpLab2, QtpLab3 }; 
            int i = 0;
            while (reader.Read())
            {
                question[i].Text = reader["题目"].ToString();
                
                type[i].Text = (i+1).ToString()+"."+reader["类型"].ToString()+"：";
                i++;
            }
            qnumber = i;
            justfy_interface(i);
            selectCmd = "select [截止日期] from [work_info] where [题号]='" + qid + "'";
            cmd = new OleDbCommand(selectCmd, conn);
            deadline.Text = cmd.ExecuteScalar().ToString();
            //获取答案
            switch (qnumber)
            {
                case 1: selectCmd = "select [答案1] from [answer] where [学号]='"
                    + HttpContext.Current.User.Identity.Name + "' and [题号]='" + qid + "'"; break;
                case 2: selectCmd = "select [答案1],[答案2] from [answer] where [学号]='"
                    + HttpContext.Current.User.Identity.Name + "' and [题号]='" + qid + "'"; break;
                case 3: selectCmd = "select [答案1],[答案2],[答案3] from [answer] where [学号]='"
                    + HttpContext.Current.User.Identity.Name + "' and [题号]='" + qid + "'"; break;
            }
            cmd = new OleDbCommand(selectCmd, conn);
            reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                switch (qnumber)
                {
                    case 1: Ans1Txb.Text = reader["答案1"].ToString(); break;
                    case 2:
                        {
                            Ans1Txb.Text = reader["答案1"].ToString();
                            Ans2Txb.Text = reader["答案2"].ToString(); break;
                        }
                    case 3:
                        {
                            Ans1Txb.Text = reader["答案1"].ToString();
                            Ans2Txb.Text = reader["答案2"].ToString(); 
                            Ans3Txb.Text = reader["答案3"].ToString(); break;
                        }
                }
            }
            conn.Close();
        }

        protected void justfy_interface(int qnum)
        {
            switch (qnum)
            {
                case 0:
                    Label2.Text = "暂时没有需要完成的作业";
                    DropDownList1.Visible = false;
                    Label1.Visible = false;
                    SaveBtn.Visible = false;SubmitBtn.Visible = false;
                    SaveLab.Visible = false;SubmitLab.Visible=false;
                    QtpLab1.Visible = false; QtpLab2.Visible = false; QtpLab3.Visible = false;
                    Q1Lab.Visible = false; Q2Lab.Visible = false; Q3Lab.Visible = false;
                    Ans1Txb.Visible = false; Ans2Txb.Visible = false; Ans3Txb.Visible = false; break;
                case 1:
                    Label2.Text = "截止日期";
                    Label1.Visible = true; DropDownList1.Visible = true;
                    SaveBtn.Visible = true;SubmitBtn.Visible = true;
                    SaveLab.Visible = true;SubmitLab.Visible=true;
                    QtpLab1.Visible = true; QtpLab2.Visible = false; QtpLab3.Visible = false;
                    Q1Lab.Visible = true; Q2Lab.Visible = false; Q3Lab.Visible = false; 
                    Ans1Txb.Visible=true;Ans2Txb.Visible=false;Ans3Txb.Visible=false; break;
                case 2:
                    Label2.Text = "截止日期";
                    Label1.Visible = true; DropDownList1.Visible = true;
                    SaveBtn.Visible = true;SubmitBtn.Visible = true;
                    SaveLab.Visible = true;SubmitLab.Visible=true;
                    QtpLab1.Visible = true; QtpLab2.Visible = true; QtpLab3.Visible = false;
                    Q1Lab.Visible = true; Q2Lab.Visible = true; Q3Lab.Visible = false;
                    Ans1Txb.Visible = true; Ans2Txb.Visible = true; Ans3Txb.Visible = false; break;
                case 3:
                    Label2.Text = "截止日期";
                    Label1.Visible = true; DropDownList1.Visible = true;
                    SaveBtn.Visible = true;SubmitBtn.Visible = true;
                    SaveLab.Visible = true;SubmitLab.Visible=true;
                    QtpLab1.Visible = true; QtpLab2.Visible = true; QtpLab3.Visible = true;
                    Q1Lab.Visible = true; Q2Lab.Visible = true; Q3Lab.Visible = true;
                    Ans1Txb.Visible = true; Ans2Txb.Visible = true; Ans3Txb.Visible = true; break;
            }
        }

        protected void SubmitBtn_Click(object sender, ImageClickEventArgs e)
        {
            string updateCmd="";
            switch (qnumber)
            {
                case 1:
                    updateCmd = "update [answer] set [答案1] = '" + Ans1Txb.Text + "',[提交否]='是' where [题号]='" 
                        + DropDownList1.SelectedValue + "' and [学号] = '"
                        + HttpContext.Current.User.Identity.Name + "'"; break;
                case 2:
                    updateCmd = "update [answer] set [答案1] = '" + Ans1Txb.Text + "',[答案2]='" + Ans2Txb.Text
                        + "',[提交否]='是' where [题号]='" + DropDownList1.SelectedValue + "' and [学号] = '"
                        + HttpContext.Current.User.Identity.Name + "'";break;
                case 3:
                    updateCmd = "update [answer] set [答案1] = '" + Ans1Txb.Text + "',[答案2]='" + Ans2Txb.Text
                        + "',[答案3]='" + Ans3Txb.Text + "',[提交否]='是' where [题号]='" + DropDownList1.SelectedValue + "' and [学号] = '"
                        + HttpContext.Current.User.Identity.Name + "'";break;
            }
            try
            {
                conn.Open();
                cmd = new OleDbCommand(updateCmd, conn);
                cmd.ExecuteNonQuery();

                updateCmd = "update [work_info] set [未提交]=[未提交]-1,[待批改]=[待批改]+1 where [题号]='" + DropDownList1.SelectedValue + "'";
                cmd = new OleDbCommand(updateCmd, conn);
                cmd.ExecuteNonQuery();
                conn.Close();
                Response.Write("<script>alert('提交成功');location.href='submited.aspx';</script>");
            }
            catch (System.Exception ex)
            {
                conn.Close();
                Response.Write("<script>alert('提交失败');</script>");
            }    
        }

        protected void SaveBtn_Click(object sender, ImageClickEventArgs e)
        {
            string updateCmd="";
            switch(qnumber)
            {
                case 1: updateCmd = "update [answer] set [答案1]='" + Ans1Txb.Text + "' where [学号]='"
                     + HttpContext.Current.User.Identity.Name + "' and [题号]='" + DropDownList1.SelectedValue + "'"; break;

                case 2: updateCmd = "update [answer] set [答案1]='" + Ans1Txb.Text + "',[答案2]='"
                     + Ans2Txb.Text + "' where [学号]='"+ HttpContext.Current.User.Identity.Name 
                     + "' and [题号]='" + DropDownList1.SelectedValue + "'"; break;

                case 3: updateCmd = "update [answer] set [答案1]='" + Ans1Txb.Text + "',[答案2]='"
                     + Ans2Txb.Text + "',[答案3]='"+Ans3Txb.Text+"' where [学号]='" + HttpContext.Current.User.Identity.Name
                     + "' and [题号]='" + DropDownList1.SelectedValue + "'"; break;
            }
            cmd = new OleDbCommand(updateCmd, conn);
            conn.Open();
            try
            {
                cmd.ExecuteNonQuery();
                conn.Close();
                Response.Write("<script>alert('暂存成功！');location.href='undone.aspx';</script>");
            }
            catch (System.Exception ex)
            {
                conn.Close();
                Response.Write("<script>alert('暂存失败！');</script>");	
            }
        }

    }
}