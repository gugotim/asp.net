﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;

namespace 在线作业管理系统
{
    public partial class motify : System.Web.UI.Page
    {
        string dbstr;
        OleDbConnection conn = new OleDbConnection();
        OleDbCommand cmd;
        protected void Page_Load(object sender, EventArgs e)
        {
            dbstr = "Provider=Microsoft.Jet.OLEDB.4.0;data source=" + MapPath("../data/am.mdb");
            conn.ConnectionString = dbstr;

            string selectCmd = "select count(*) from [work_info]";
            cmd = new OleDbCommand(selectCmd, conn);
            conn.Open();
            if (Convert.ToInt32(cmd.ExecuteScalar()) == 0)
            {
                alert2.InnerText = "目前没有布置作业";
            }
            else alert2.InnerText = "请选择以查看详细信息并酌情修改";
            conn.Close();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string no = GridView1.SelectedRow.Cells[1].Text;
            string qnumber = GridView1.SelectedRow.Cells[5].Text;
            Response.Cookies["qno"].Value = no;
            Response.Cookies["qnum"].Value = qnumber;
            switch (qnumber)
            {
                case "1": Response.Redirect("modify1.aspx"); break;
                case "2": Response.Redirect("modify2.aspx"); break;
                case "3": Response.Redirect("modify3.aspx"); break;
            }
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Button1.Enabled = true;
        }
    }
}