﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;

namespace 在线作业管理系统
{
    public partial class modify3 : System.Web.UI.Page
    {
        string dbstr;
        OleDbConnection conn = new OleDbConnection();
        OleDbCommand cmd = new OleDbCommand();
        OleDbDataReader reader;
        protected void Page_Load(object sender, EventArgs e)
        {
            dbstr = "Provider=Microsoft.Jet.OLEDB.4.0;data source=" + MapPath("../data/am.mdb");
            conn.ConnectionString = dbstr;
            if (!IsPostBack)
            {
                string no = "";
                try
                {
                    no = Request.Cookies["qno"].Value;
                    QnoTxb.Text = no;
                }
                catch (System.Exception ex)
                {
                    Server.Transfer("default.aspx");
                }

                conn.Open();

                string selectCmd = "select [评分标准],[截止日期],[公布否] from [work_info] where [题号]='" + no + "'";
                cmd = new OleDbCommand(selectCmd, conn);
                reader = cmd.ExecuteReader();
                string announced = "";
                while (reader.Read())
                {
                    judgement.SelectedValue = reader[0].ToString();
                    deadline.Text = reader[1].ToString();
                    announced = reader[2].ToString();
                }
                if (announced.Equals("是"))
                {
                    Label1.Text = "这个作业已经公布成绩了，不能修改了呦";
                    EditBtn.Enabled = false;
                }
                else Label1.Text = "作业修改后，所有同学都需要重新完成";

                selectCmd = "select [类型],[题目] from [assignment] where [题号]='" + no + "'";
                cmd = new OleDbCommand(selectCmd, conn);

                reader = cmd.ExecuteReader();
                DropDownList[] ddl = { Qtypeddl1, Qtypeddl2, Qtypeddl3 };
                TextBox[] txb = { Qtxb1, Qtxb2, Qtxb3 };
                int i = 0;
                while (reader.Read())
                {
                    ddl[i].Text = reader[0].ToString();
                    txb[i].Text = reader[1].ToString();
                    i++;
                }
                reader.Close();
                conn.Close();

                changeControlState(false);
            }
            if (QnoTxb.Text.Equals(""))
            {
                Response.Redirect("default.aspx");
            }
        }

        protected void EditBtn_Click(object sender, EventArgs e)
        {
            EditBtn.Visible = false;
            changeControlState(true);
        }

        protected void CancelBtn_Click(object sender, EventArgs e)
        {
            Response.Write("<script>location.href='modify3.aspx';</script>");
        }

        protected void changeControlState(bool jdg)
        {
            RegularExpressionValidator1.Enabled = jdg;
            RegularExpressionValidator2.Enabled = jdg;
            RegularExpressionValidator3.Enabled = jdg;
            RequiredFieldValidator1.Enabled = jdg;
            RequiredFieldValidator2.Enabled = jdg;
            RequiredFieldValidator3.Enabled = jdg;
            RequiredFieldValidator4.Enabled = jdg;
            UptBtn.Visible = jdg;
            CancelBtn.Visible = jdg;

            judgement.Enabled = jdg;
            deadline.Enabled = jdg;
            Qtypeddl1.Enabled = jdg;
            Qtypeddl2.Enabled = jdg;
            Qtypeddl3.Enabled = jdg;
            Qtxb1.Enabled = jdg;
            Qtxb2.Enabled = jdg;
            Qtxb3.Enabled = jdg;
        }

        protected void UptBtn_Click(object sender, EventArgs e)
        {
            conn.Open();
            OleDbTransaction trans = conn.BeginTransaction();
            cmd = conn.CreateCommand();
            cmd.Transaction = trans;
            try
            {
                //获取所有学生数
                string updateCmd = "select count(*) from stu";
                cmd.CommandText = updateCmd;
                int stunum = Convert.ToInt32(cmd.ExecuteScalar());
                //修改评分标准、截止日期，同时使 未提交数为初始状态（所有学生），待评分为0
                updateCmd = "update [work_info] set [评分标准] = '" + judgement.Text + "',[截止日期]='" + deadline.Text +
                    "',[待批改] = 0,[未提交] =" + stunum + " where [题号] = '" + QnoTxb.Text + "'";
                cmd.CommandText = updateCmd;
                cmd.ExecuteNonQuery();
                //获取题目信息
                string[] type = { Qtypeddl1.SelectedValue, Qtypeddl2.SelectedValue, Qtypeddl3.SelectedValue };
                string[] question = { Qtxb1.Text, Qtxb2.Text, Qtxb3.Text };
                for (int i = 0; i < 3;i++ )
                {
                    updateCmd = "update [assignment] set [类型]='" + type[i] + "',[题目]='" + question[i] + "' where [题号]='" +
                        QnoTxb.Text + "' and [no]=" + (i+1);
                    cmd.CommandText = updateCmd;
                    cmd.ExecuteNonQuery();
                }
                //将所有同学作业的状态退回为 未提交，评分为初始的 'false'
                updateCmd = "update [answer] set [提交否] = '否',[评分] = 'false' where [题号] = '" + QnoTxb.Text + "'";
                cmd.CommandText = updateCmd;
                cmd.ExecuteNonQuery();
                trans.Commit();
                conn.Close();
                Response.Write("<script>alert('修改成功');location.href='modify3.aspx';</script>");
            }
            catch (System.Exception ex)
            {
                conn.Close();
                Response.Write("<script>alert('修改失败<br />+"+ex.Message+"');location.href='modify3.aspx';</script>");
            }
        }
    }
}