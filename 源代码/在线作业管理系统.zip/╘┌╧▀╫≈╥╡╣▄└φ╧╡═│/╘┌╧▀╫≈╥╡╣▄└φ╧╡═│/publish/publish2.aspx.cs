﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;

namespace 在线作业管理系统
{
    public partial class publish2 : System.Web.UI.Page
    {
        string dbstr;
        OleDbConnection conn = new OleDbConnection();
        OleDbCommand cmd = new OleDbCommand();
        OleDbDataReader reader;
        protected void Page_Load(object sender, EventArgs e)
        {
            dbstr = "Provider=Microsoft.Jet.OLEDB.4.0;data source=" + MapPath("../data/am.mdb");
            conn.ConnectionString = dbstr;
            if (!IsPostBack)
            {
                fresh_id();
                submitBtn.Enabled = true;
            }
        }

        protected void fresh_id()
        {
            string selectCmd = "select count(*) from work_info where 发布日期='" + DateTime.Now.ToString("yyyy-MM-dd") + "'";
            cmd = new OleDbCommand(selectCmd, conn);

            conn.Open();
            QnoTxb.Text = DateTime.Now.ToString("yyyy-MM-dd") + "-" + (Convert.ToInt32(cmd.ExecuteScalar()) + 1).ToString();
            conn.Close();
        }

        protected void submitBtn_Click(object sender, EventArgs e)
        {
            conn.Open();
            //在答案表中加入学生信息
            string selectCmd = "select [学号] from [stu]";
            cmd = new OleDbCommand(selectCmd, conn);
            reader = cmd.ExecuteReader();
            int stunum=0;
            while (reader.Read())
            {
                string insertIntoAnswer = "insert into [answer]([题号],[学号],[评分]) values(?,?,?)";
                cmd = new OleDbCommand(insertIntoAnswer, conn);
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("题号", QnoTxb.Text);
                cmd.Parameters.AddWithValue("学号", Convert.ToInt32(reader["学号"]));
                cmd.Parameters.AddWithValue("评分", "false");
                cmd.ExecuteNonQuery();
                stunum++;
            }

            string insertInfo = "INSERT INTO [work_info]([题号],[发布日期],[评分标准],[截止日期],[题数],[未提交]) VALUES(?,?,?,?,?,?)";
            cmd = new OleDbCommand(insertInfo, conn);
            cmd.Parameters.AddWithValue("题号", QnoTxb.Text);
            cmd.Parameters.AddWithValue("发布日期", DateTime.Now.ToString("yyyy-MM-dd").ToString());
            cmd.Parameters.AddWithValue("评分标准", judgement.SelectedValue);
            cmd.Parameters.AddWithValue("截止日期", deadline.Text);
            cmd.Parameters.AddWithValue("题数", 2);
            cmd.Parameters.AddWithValue("未提交", stunum);
            cmd.ExecuteNonQuery();

            string[] type = { Qtypeddl1.SelectedValue, Qtypeddl2.SelectedValue };
            string[] question = { Qtxb1.Text, Qtxb2.Text };
            for (int i = 1; i <= 2; i++)
            {
                string insertDetail = "insert into [assignment]([题号],[no],[类型],[题目]) values(?,?,?,?)";
                cmd = new OleDbCommand(insertDetail, conn);
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("题号", QnoTxb.Text);
                cmd.Parameters.AddWithValue("no", i);
                cmd.Parameters.AddWithValue("类型", type[i - 1]);
                cmd.Parameters.AddWithValue("题目", question[i - 1]);
                cmd.ExecuteNonQuery();
            }


            conn.Close();
            Response.Write("<script>alert('布置成功!');location.href='../modify/';</script>");
        }
    }
}