﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;
using System.Web.Security;

namespace 在线作业管理系统
{
    public partial class Sinfo : System.Web.UI.Page
    {
        string dbstr,selectCmd,stu_no;
        OleDbConnection conn = new OleDbConnection();
        OleDbCommand cmd;
        protected void Page_Load(object sender, EventArgs e)
        {
            stu_no = HttpContext.Current.User.Identity.Name;
            dbstr = "Provider=Microsoft.Jet.OLEDB.4.0;data source=" + MapPath("../data/am.mdb");
            conn.ConnectionString = dbstr;
            conn.Open();

            //待提交作业数
            selectCmd = "SELECT count(*) FROM [work_info],[answer] WHERE ([截止日期] >= '" + DateTime.Now.ToString("yyyy-MM-dd")
                + "') and ([work_info].[题号] = [answer].[题号]) and ([answer].[提交否] = '否') and([学号] = '" + stu_no + "')";
            cmd = new OleDbCommand(selectCmd, conn);
            if (Convert.ToInt32(cmd.ExecuteScalar()) != 0)
            {
                undoneLab.Text = "你有" + cmd.ExecuteScalar().ToString() + "个作业需要完成呦";
            }
            else undoneLab.Text = "最近的作业都做完啦";

            //待批改作业数
            selectCmd = "SELECT count(*) FROM [work_info],[answer] WHERE ([work_info].[题号] = [answer].[题号]) and ([answer].[提交否] = '是')"
                +" and([学号] = '"+stu_no+"') and([work_info].[公布否] = '否')";
            cmd = new OleDbCommand(selectCmd, conn);
            if (Convert.ToInt32(cmd.ExecuteScalar()) != 0)
            {
                TomarkLab.Text = "看看等待批改的" + cmd.ExecuteScalar().ToString() + "项作业吧";
            }
            else TomarkLab.Text = "没有等待批改的作业呦";

            //已过期作业数
            selectCmd = "SELECT count(*) FROM [work_info],[answer] WHERE ([截止日期] < '"+DateTime.Now.ToString("yyyy-MM-dd")
                +"') and ([work_info].[题号] = [answer].[题号]) and ([answer].[提交否] = '否') and([学号] = '"+stu_no+"')";
            cmd = new OleDbCommand(selectCmd, conn);
            if (Convert.ToInt32(cmd.ExecuteScalar()) != 0)
            {
                expiredLab.Text = "啊哦，你有" + cmd.ExecuteScalar().ToString() + "项作业没有按时提交。。";
            }
            else expiredLab.Text = "恭喜，你没有过期的作业";

            //已评分作业数
            selectCmd = "SELECT count(*) FROM [answer],[work_info] WHERE ([学号] = '"+stu_no
                +"') and [work_info].[公布否] = '是' and ([work_info].[题号] = [answer].[题号]) and ([answer].[提交否] <> '否')";
            cmd = new OleDbCommand(selectCmd, conn);
            if (Convert.ToInt32(cmd.ExecuteScalar())!=0)
            {
                AnnouncedLab.Text = cmd.ExecuteScalar().ToString() + "项作业已经出成绩了，去看看吧";
            }
            else AnnouncedLab.Text = "暂时没有评好分的作业。。";

            //获取学生姓名
            selectCmd = "select [姓名] from [stu] where [学号]='" + stu_no + "'";
            cmd = new OleDbCommand(selectCmd, conn);
            if (cmd.ExecuteScalar()!=null)
            {
                StunameLab.Text = cmd.ExecuteScalar().ToString();
            }
            else StunameLab.Text = HttpContext.Current.User.Identity.Name;

            //判断时间是上午还是下午
            if (DateTime.Now.Hour > 12)
            {
                AorPLab.Text = "下午好！";
            }
            else AorPLab.Text = "上午好！";

            conn.Close();
        }
    }
}