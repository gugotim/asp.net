﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;

namespace 在线作业管理系统.stu
{
    public partial class ans2 : System.Web.UI.Page
    {
        string dbstr;
        string q_no, stu_no;
        OleDbConnection conn = new OleDbConnection();
        OleDbCommand cmd;
        OleDbDataReader reader;
        protected void Page_Load(object sender, EventArgs e)
        {
            dbstr = "Provider=Microsoft.Jet.OLEDB.4.0;data source=" + MapPath("../data/am.mdb");
            conn.ConnectionString = dbstr;
            if (!IsPostBack)
            {
                stu_no = HttpContext.Current.User.Identity.Name;
                try
                {
                    q_no = Request.Cookies["no"].Value;
                    QnoTxb.Text = q_no;
                }
                catch (System.Exception ex)
                {
                    Server.Transfer("undone.aspx");
                }

                conn.Open();
                //读取截止日期
                string selectCmd = "select [截止日期] from [work_info] where [题号]='" + q_no + "'";
                cmd = new OleDbCommand(selectCmd, conn);
                reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    deadline.Text = reader[0].ToString();
                }
                //读取题目
                selectCmd = "select [类型],[题目] from [assignment] where [题号]='" + q_no + "'";
                cmd = new OleDbCommand(selectCmd, conn);

                reader = cmd.ExecuteReader();
                Label[] type = { Qtype1, Qtype2 };
                TextBox[] txb = { Qtxb1, Qtxb2 };
                int i = 0;
                while (reader.Read())
                {
                    type[i].Text = reader[0].ToString();
                    txb[i].Text = reader[1].ToString();
                    i++;
                }
                //读取答案
                selectCmd = "select [答案1],[答案2] from [answer] where [题号]='" + QnoTxb.Text + "' and [学号]='" + HttpContext.Current.User.Identity.Name + "'";
                cmd = new OleDbCommand(selectCmd, conn);
                reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Ans1.Text = reader[0].ToString();
                    Ans2.Text = reader[1].ToString();
                }

                conn.Close();
            }

        }

        protected void EditBtn_Click(object sender, EventArgs e)
        {
            string updateCmd = "update [answer] set [答案1] = '" + Ans1.Text + "',[答案2]='" + Ans2.Text
                + "' where [题号]='" + QnoTxb.Text + "' and [学号] = '" + HttpContext.Current.User.Identity.Name + "'";
            cmd = new OleDbCommand(updateCmd, conn);
            try
            {
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
                Response.Write("<script>alert('暂存成功');location.href='undone.aspx';</script>");
            }
            catch (System.Exception ex)
            {
                conn.Close();
                Response.Write("<script>alert('暂存失败');</script>");
            }      

        }

        protected void UptBtn_Click(object sender, EventArgs e)
        {
            string updateCmd = "update [answer] set [答案1] = '" + Ans1.Text + "',[答案2]='" + Ans2.Text
                + "',[提交否]='是' where [题号]='" + QnoTxb.Text + "' and [学号] = '" + HttpContext.Current.User.Identity.Name + "'";
            cmd = new OleDbCommand(updateCmd, conn);
            try
            {
                conn.Open();
                cmd.ExecuteNonQuery();

                updateCmd = "update [work_info] set [未提交]=[未提交]-1,[待批改]=[待批改]+1 where [题号]='" + QnoTxb.Text + "'";
                cmd = new OleDbCommand(updateCmd, conn);
                cmd.ExecuteNonQuery();
                conn.Close();
                Response.Write("<script>alert('提交成功');location.href='submited.aspx';</script>");
            }
            catch (System.Exception ex)
            {
                conn.Close();
                Response.Write("<script>alert('提交失败');</script>");
            }               
        }
    }
}