﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;
using System.Web.Security;

namespace 在线作业管理系统.stu
{
    public partial class changeinfo : System.Web.UI.Page
    {
        string stu_no, dbstr;
        OleDbConnection conn = new OleDbConnection();
        OleDbCommand cmd;
        protected void Page_Load(object sender, EventArgs e)
        {
            dbstr = "Provider=Microsoft.Jet.OLEDB.4.0;data source=" + MapPath("../data/am.mdb");
            conn.ConnectionString = dbstr;
            if (!IsPostBack)
            {
                string selectCmd = "select [姓名] from [stu] where [学号]='" + HttpContext.Current.User.Identity.Name + "'";
                cmd = new OleDbCommand(selectCmd, conn);
                conn.Open();
                StunameLab.Text = cmd.ExecuteScalar().ToString();
                conn.Close();

                if (DateTime.Now.Hour > 12)
                {
                    AorPLab.Text = "下午好！";
                }
                else AorPLab.Text = "上午好！";
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (CustomValidator1.IsValid)
            {
                string updateCmd = "update [stu] set [密码]=? where [学号]=?";
                try
                {
                    conn.Open();
                    cmd = new OleDbCommand(updateCmd, conn);
                    cmd.Parameters.Clear();
                    cmd.Parameters.AddWithValue("密码", NewPwdTxb.Text);
                    cmd.Parameters.AddWithValue("学号", HttpContext.Current.User.Identity.Name);
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    Response.Write("<script>alert('修改成功');location.href='sinfo.aspx';</script>");
                }
                catch (System.Exception ex)
                {
                    conn.Close();
                    Response.Write("<script>alert('修改失败');</script>");
                }
            }
        }

        protected void CustomValidator1_ServerValidate(object source, ServerValidateEventArgs args)
        {
            conn.Open();
            string selectCmd = "select [密码] from [stu] where [学号]=?";
            cmd = new OleDbCommand(selectCmd, conn);
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("学号", HttpContext.Current.User.Identity.Name);
            if (cmd.ExecuteScalar().ToString().Equals(args.Value))
            {
                args.IsValid = true;
            }
            else args.IsValid = false;
            conn.Close();
        }
    }
}