﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;

namespace 在线作业管理系统.stu
{
    public partial class ed3 : System.Web.UI.Page
    {
        string dbstr;
        string q_no, stu_no;
        OleDbConnection conn = new OleDbConnection();
        OleDbCommand cmd;
        OleDbDataReader reader;
        protected void Page_Load(object sender, EventArgs e)
        {
            dbstr = "Provider=Microsoft.Jet.OLEDB.4.0;data source=" + MapPath("../data/am.mdb");
            conn.ConnectionString = dbstr;
            if (!IsPostBack)
            {
                try
                {
                    q_no = Request.Cookies["no"].Value;
                    QnoTxb.Text = q_no;
                }
                catch (System.Exception ex)
                {
                    Response.Redirect("expired.aspx");                	
                }

                conn.Open();
                //读取题目
                string selectCmd = "select [类型],[题目] from [assignment] where [题号]='" + q_no + "'";
                cmd = new OleDbCommand(selectCmd, conn);

                reader = cmd.ExecuteReader();
                Label[] type = { Qtype1, Qtype2, Qtype3 };
                TextBox[] txb = { Qtxb1, Qtxb2, Qtxb3 };
                int i = 0;
                while (reader.Read())
                {
                    type[i].Text = reader[0].ToString();
                    txb[i].Text = reader[1].ToString();
                    i++;
                }
                //读取截止日期
                selectCmd = "select [截止日期] from [work_info] where [题号]='" + QnoTxb.Text + "'";
                cmd = new OleDbCommand(selectCmd, conn);
                reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    deadline.Text = reader[0].ToString();
                }
                conn.Close();
            }
        }

        protected void BackBtn_Click(object sender, EventArgs e)
        {
            Response.Redirect("expired.aspx");
        }
    }
}