﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;

namespace 在线作业管理系统.stu
{
    public partial class marked : System.Web.UI.Page
    {
        string dbstr, selectCmd, stu_no;
        OleDbConnection conn = new OleDbConnection();
        OleDbCommand cmd;
        string qnum;
        string qno;
        protected void Page_Load(object sender, EventArgs e)
        {
            dbstr = "Provider=Microsoft.Jet.OLEDB.4.0;data source=" + MapPath("../data/am.mdb");
            conn.ConnectionString = dbstr;
            if (!IsPostBack)
            {
                try
                {
                    stu_no = HttpContext.Current.User.Identity.Name;
                    stuLab.Text = stu_no;
                }
                catch (System.Exception ex)
                {
                    Response.Redirect("<script>alert('请以学号登陆');location.href='../login.aspx';</script>");
                }
                conn.Open();
                //已评分作业数
                selectCmd = "SELECT count(*) FROM [answer],[work_info] WHERE ([学号] = '" + stu_no
                    + "') and [work_info].[公布否] = '是' and ([work_info].[题号] = [answer].[题号]) and ([answer].[提交否] <> '否')";
                cmd = new OleDbCommand(selectCmd, conn);
                if (Convert.ToInt32(cmd.ExecuteScalar()) != 0)
                {
                    info.Text = cmd.ExecuteScalar().ToString() + "项作业已经出成绩了，去看看吧";
                }
                else info.Text = "暂时没有评好分的作业。。";
                conn.Close();
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            qno = GridView1.SelectedRow.Cells[1].Text;
            string selectCmd = "select [题数] from [work_info] where [题号]='" + qno + "'";
            cmd = new OleDbCommand(selectCmd, conn);
            conn.Open();
            qnum = cmd.ExecuteScalar().ToString();
            conn.Close();
            Response.Cookies["no"].Value = qno;
            switch (qnum)
            {
                case "1": Response.Redirect("md1.aspx"); break;
                case "2": Response.Redirect("md2.aspx"); break;
                case "3": Response.Redirect("md3.aspx"); break;
            }
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Button1.Enabled = true;
        }
    }
}