﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;

namespace 在线作业管理系统.stu
{
    public partial class md3 : System.Web.UI.Page
    {
        string dbstr;
        string q_no, stu_no;
        OleDbConnection conn = new OleDbConnection();
        OleDbCommand cmd;
        OleDbDataReader reader;
        protected void Page_Load(object sender, EventArgs e)
        {
            dbstr = "Provider=Microsoft.Jet.OLEDB.4.0;data source=" + MapPath("../data/am.mdb");
            conn.ConnectionString = dbstr;
            if (!IsPostBack)
            {
                try
                {
                    stu_no = HttpContext.Current.User.Identity.Name;
                    q_no = Request.Cookies["no"].Value;
                    QnoTxb.Text = q_no;
                }
                catch (System.Exception ex)
                {
                    Response.Redirect("marked.aspx");                	
                }

                conn.Open();
                //读取题目
                string selectCmd = "select [类型],[题目] from [assignment] where [题号]='" + q_no + "'";
                cmd = new OleDbCommand(selectCmd, conn);

                reader = cmd.ExecuteReader();
                Label[] type = { Qtype1, Qtype2, Qtype3 };
                TextBox[] txb = { Qtxb1, Qtxb2, Qtxb3 };
                int i = 0;
                while (reader.Read())
                {
                    type[i].Text = reader[0].ToString();
                    txb[i].Text = reader[1].ToString();
                    i++;
                }
                //读取答案
                selectCmd = "select [答案1],[答案2],[答案3],[评分] from [answer] where [题号]='" + QnoTxb.Text + "' and [学号]='"
                    + stu_no + "'";
                cmd = new OleDbCommand(selectCmd, conn);
                reader = cmd.ExecuteReader();
                string score = "";
                while (reader.Read())
                {
                    Ans1.Text = reader["答案1"].ToString();
                    Ans2.Text = reader["答案2"].ToString();
                    Ans3.Text = reader["答案3"].ToString();
                    score = reader["评分"].ToString();
                }
                scoreTxb.Text = score;
                conn.Close();
            }
        }

        protected void BackBtn_Click(object sender, EventArgs e)
        {
            Response.Redirect("marked.aspx");
        }
    }
}