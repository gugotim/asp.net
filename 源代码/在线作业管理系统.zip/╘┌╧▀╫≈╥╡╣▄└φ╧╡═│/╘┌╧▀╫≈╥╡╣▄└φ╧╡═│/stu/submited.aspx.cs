﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;

namespace 在线作业管理系统.stu
{
    public partial class submited : System.Web.UI.Page
    {
        string dbstr, selectCmd, stu_no;
        OleDbConnection conn = new OleDbConnection();
        OleDbCommand cmd;
        protected void Page_Load(object sender, EventArgs e)
        {
            dbstr = "Provider=Microsoft.Jet.OLEDB.4.0;data source=" + MapPath("../data/am.mdb");
            conn.ConnectionString = dbstr;
            if (!IsPostBack)
            {
                try
                {
                    stu_no = HttpContext.Current.User.Identity.Name;
                    stuLab.Text = stu_no;
                }
                catch (System.Exception ex)
                {
                    Response.Redirect("<script>alert('请以学号登陆');location.href='../login.aspx';</script>");
                }
                conn.Open();
                //待批改作业数
                selectCmd = "SELECT count(*) FROM [work_info],[answer] WHERE ([work_info].[题号] = [answer].[题号]) and ([answer].[提交否] = '是')"
                    + " and([学号] = '" + stu_no + "') and([work_info].[公布否] = '否')";
                cmd = new OleDbCommand(selectCmd, conn);
                if (Convert.ToInt32(cmd.ExecuteScalar()) != 0)
                {
                    info.Text = "看看等待批改的" + cmd.ExecuteScalar().ToString() + "项作业吧";
                }
                else info.Text = "没有等待批改的作业呦";
                conn.Close();
            }
            timeLab.Text = DateTime.Now.ToString("yyyy-MM-dd");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string no = GridView1.SelectedRow.Cells[1].Text;
            string qnum = GridView1.SelectedRow.Cells[5].Text;
            Response.Cookies["no"].Value = no;
            switch (qnum)
            {
                case "1": Response.Redirect("sd1.aspx"); break;
                case "2": Response.Redirect("sd2.aspx"); break;
                case "3": Response.Redirect("sd3.aspx"); break;
            }
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Button1.Enabled = true;
        }
    }
}