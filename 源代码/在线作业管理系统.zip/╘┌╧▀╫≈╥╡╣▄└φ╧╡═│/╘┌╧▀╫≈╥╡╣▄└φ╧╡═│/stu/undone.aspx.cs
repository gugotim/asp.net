﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using System.Data;
using System.Data.OleDb;

namespace 在线作业管理系统.stu
{
    public partial class _default : System.Web.UI.Page
    {
        string dbstr, selectCmd, stu_no;
        OleDbConnection conn = new OleDbConnection();
        OleDbCommand cmd;
        protected void Page_Load(object sender, EventArgs e)
        {
            timeLab.Text = DateTime.Now.ToString("yyyy-MM-dd");
            if (!IsPostBack)
            {
                try
                {
                    stu_no = HttpContext.Current.User.Identity.Name;
                }
                catch (System.Exception ex)
                {
                    Response.Redirect("<script>alert('请以学号登陆');location.href='../login.aspx';</script>");
                }
                Label1.Text = "否";
                stuLab.Text = stu_no;
                dbstr = "Provider=Microsoft.Jet.OLEDB.4.0;data source=" + MapPath("../data/am.mdb");
                conn.ConnectionString = dbstr;
                conn.Open();


                //待提交作业数
                selectCmd = "SELECT count(*) FROM [work_info],[answer] WHERE ([截止日期] >= '" + DateTime.Now.ToString("yyyy-MM-dd")
                    + "') and ([work_info].[题号] = [answer].[题号]) and ([answer].[提交否] = '否') and([学号] = '" + stu_no + "')";
                cmd = new OleDbCommand(selectCmd, conn);
                if (Convert.ToInt32(cmd.ExecuteScalar()) != 0)
                {
                    info.Text = "你有" + cmd.ExecuteScalar().ToString() + "个作业需要完成呦";
                }
                else info.Text = "最近的作业都做完啦";

                conn.Close();

            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string no = GridView1.SelectedRow.Cells[1].Text;
            string qnum=GridView1.SelectedRow.Cells[5].Text;
            Response.Cookies["no"].Value = no;
            switch (qnum)
            {
                case "1": Response.Redirect("ans1.aspx"); break;
                case "2": Response.Redirect("ans2.aspx"); break;
                case "3": Response.Redirect("ans3.aspx"); break;
            }            
        }

        protected void GridView1_SelectedIndexChanged1(object sender, EventArgs e)
        {
            Button1.Enabled = true;
        }
    }
}